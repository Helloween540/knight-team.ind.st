<?php
$emailku = 'ff@gmail.com'; // GANTI EMAIL KAMU DISINI
?>